# GitHub Assistant

## What it does ##

The extension includes:

* set notes to a github Mr by actions created in json options
